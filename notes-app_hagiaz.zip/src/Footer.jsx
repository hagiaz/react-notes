/* eslint-disable no-unused-vars */
import React from "react";

function Footer() {
    return (
        <nav className="footer" >
            <p className="footer-text" >Final Project Kelas Belajar Membuat Aplikasi Web dengan React - Dicoding Academy</p>
            <p className="footer-text" >Hagi Azzam Azzikri - 2024</p>
        </nav>
    );
}

export default Footer;