/* eslint-disable no-unused-vars */
import React from "react";

function Navbar() {
    return (
        <nav className="navbar" >
            <p className="navbar-links" >Your Personal Notes Web App</p>
        </nav>
    );
}

export default Navbar;